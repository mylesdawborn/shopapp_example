import 'package:flutter/material.dart';
import 'package:shopapp_example/pages/login.dart';

void main() {
  runApp(new MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Login(),
  ));
}

